# ORBIT07 Telegram Push Bot (Webhook)

A minimal, production-lean Telegram bot for webhook + cron (Asia/Taipei), tailored for 戀股主場。
Includes: secret webhook path, auto chat registration, /broadcast, and daily schedules.

## 1) Setup

```bash
cp .env.example .env
# edit .env:
# - BOT_TOKEN: from @BotFather (regenerate if your token was ever posted publicly)
# - APP_BASE_URL: your https URL (e.g. Render)
# - WEBHOOK_SECRET: random path string
# - ADMIN_ID: your Telegram numeric user id
# - ALLOWED_CHAT_IDS: optional comma-separated whitelist
npm i
npm start
```

## 2) Set Webhook (two ways)

**A. Built-in helper:**

```
GET $APP_BASE_URL/install-webhook?key=$ADMIN_ID
```

**B. Direct via curl:**

```bash
curl -s "https://api.telegram.org/bot$BOT_TOKEN/setWebhook"   -d "url=$APP_BASE_URL/webhook/$WEBHOOK_SECRET"   -d "allowed_updates=message,edited_message,callback_query,chat_member,my_chat_member,channel_post,edited_channel_post"   -d "drop_pending_updates=true"
```

Check status:

```bash
curl -s "https://api.telegram.org/bot$BOT_TOKEN/getWebhookInfo" | jq .
```

> Note: When a webhook is set, `getUpdates` will not return messages. Use `getWebhookInfo` instead.

## 3) Register Chats

1) Add bot to a 1:1 chat or group and type `/start` once.  
2) The chat id is available via `/id`.  
3) Admin can broadcast: `/broadcast 13:40 收盤範本出稿`.

## 4) Cron Schedules (Asia/Taipei)

- 07:15 盤前導航（工作日）  
- 09:10 投顧摘要（工作日）  
- 12:30 午盤小結（工作日）  
- 13:40 收盤報告（工作日）  
- 16:00 投資日誌提醒（每日）  

Replace the placeholders to pipe real sources (TWSE, 投資家日報 OCR, 老王午報等).

## 5) Security Tips

- Keep `WEBHOOK_SECRET` random and long, e.g. 32+ chars.
- Restrict pushes to `ALLOWED_CHAT_IDS` or require `/start` registration.
- If your token ever leaked: go to @BotFather → `/revoke` to issue a new token.
- Enforce HTTPS only (Render/Cloudflare by default).

## 6) Local Test

Use a tunneling service (e.g. cloud provider or ngrok) to get a public https URL, then set webhook to `https://<tunnel>/webhook/<secret>`.
